--
-- PostgreSQL database dump
--

\restrict cznaieYl5LNw2larNe1YrhsjiNEqtu4iY5OF4f4Khc6F5lwTwNI2X25wUjQ8mU9

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict cznaieYl5LNw2larNe1YrhsjiNEqtu4iY5OF4f4Khc6F5lwTwNI2X25wUjQ8mU9

